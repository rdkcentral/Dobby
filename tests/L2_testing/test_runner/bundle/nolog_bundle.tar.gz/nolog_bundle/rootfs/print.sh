#!/bin/bash

for i in {0..10}
do
  echo "Hello World ${i}"
done
